﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Анархия_в_больнице
{
    class Program
    {
        static void Main(string[] args)
        {
            Hospital hospital = new Hospital();
            hospital.StartWork();
        }
    }

    class Hospital
    {
        private readonly List<Sick> _sicks;

        public Hospital()
        {
            _sicks = new List<Sick>();
        }

        public void StartWork()
        {
            string command = "";

            AddSicks();

            while (command != "exit")
            {
                Console.Write("Приложение - Беда в больнице.\n В данной программе есть список больных(минимум 10 записей). Класс больного состоит из: ФИО, возраст, заболевание.\n " +
                "Требуется написать программу больницы, в которой перед пользователем будет меню со следующими пунктами: 1)\n Отсортировать всех больных по фио; 2) Отсортировать всех больных" +
                " по возрасту; 3)Вывести больных с определенным\n заболеванием (название заболевания вводится пользователем с клавиатуры).\n\n Команды:\n 1) фио - сортировка больных по фио;" +
                "\n 2) возраст - сортировка больных по розрасту;\n 3) заболевание - вывести больных с определенным заболеванием;\n 4) exit - выход из программы.\n");

                ShowSicks();

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "фио":
                        SortingFullNameSicks();
                        break;
                    case "возраст":
                        SortingAgeSicks();
                        break;
                    case "заболевание":
                        OutputDiseaseSicks();
                        break;
                }

                Console.Write("\n\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение Беда в больнице завершается.\n");
        }

        private void AddSicks()
        {
            Sick sick1 = new Sick("Петров Петр Петрович", 40, "рвота");
            Sick sick2 = new Sick("Иван Иванов Иванович", 30, "заворот кишок");
            Sick sick3 = new Sick("Сидоров Сидр Сидорович", 210, "запор");
            Sick sick4 = new Sick("Александрова Александра Александровна", 35, "заноза в подбрюшье");
            Sick sick5 = new Sick("Громыхал Громыхало Громыхалыч", 50, "инсульт");
            Sick sick6 = new Sick("Распутинов Распутин Распутинович", 60, "заикание");
            Sick sick7 = new Sick("Александрован Екатерина Ильинична", 70, "зуд");
            Sick sick8 = new Sick("Алиев Денис Витальевич", 80, "рахит");
            Sick sick9 = new Sick("Ильин Александ Валерьевич", 25, "рвота");
            Sick sick10 = new Sick("Дмитриевич Ирина Евгеньевна", 35, "апатия");

            _sicks.Add(sick1);
            _sicks.Add(sick2);
            _sicks.Add(sick3);
            _sicks.Add(sick4);
            _sicks.Add(sick5);
            _sicks.Add(sick6);
            _sicks.Add(sick7);
            _sicks.Add(sick8);
            _sicks.Add(sick9);
            _sicks.Add(sick10);
        }

        private void ShowSicks()
        {
            Console.Write("\n Список больных:\n");
            for (int i = 0; i < _sicks.Count; i++)
            {
                Console.Write(" Номер - " + i);
                _sicks[i].ShowDescription();
            }
        }

        private void SortingFullNameSicks()
        {
            var resultSortingFullNameSick = _sicks.OrderBy(sick => sick.FullName).ToList();

            Console.Write("\n Сортировка cписка больных по ФИО:\n");
            for (int i = 0; i < resultSortingFullNameSick.Count; i++)
            {
                Console.Write(" Номер - " + i);
                resultSortingFullNameSick[i].ShowDescription();
            }
        }

        private void SortingAgeSicks()
        {
            var resultSortingAgeSicks = _sicks.OrderBy(sick => sick.Age).ToList();

            Console.Write("\n Сортировка cписка больных по возрасту:\n");
            for (int i = 0; i < resultSortingAgeSicks.Count; i++)
            {
                Console.Write(" Номер - " + i);
                resultSortingAgeSicks[i].ShowDescription();
            }
        }

        private void OutputDiseaseSicks()
        {
            string disease;

            Console.Write(" Введите заболевание: ");
            disease = Console.ReadLine();

            var resultOutputDiseaseSicks = _sicks.Where(sick => sick.Disease == disease).ToList();

            Console.Write("\n Список больных по заболеванию:\n");
            for (int i = 0; i < resultOutputDiseaseSicks.Count; i++)
            {
                Console.Write(" Номер - " + i);
                resultOutputDiseaseSicks[i].ShowDescription();
            }
        }
    }

    class Sick
    {
        public string FullName { get; private set; }

        public int Age { get; private set; }

        public string Disease { get; private set; }

        public Sick(string fullname, int age, string disease)
        {
            FullName = fullname;
            Age = age;
            Disease = disease;
        }

        public void ShowDescription()
        {
            Console.Write(", ФИО - " + FullName + ", возраст - " + Age + " лет, заболевание - " + Disease + ".\n");
        }
    }
}