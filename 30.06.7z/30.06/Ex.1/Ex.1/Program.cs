﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ex._1
{
    class Program
    {
       
            static void Main(string[] args)
            {
                DetectiveOffice detectiveOffice = new DetectiveOffice();
                detectiveOffice.Work();
            }
     
        class DetectiveOffice
        {
            private List<Criminal> _criminals = new List<Criminal>()
        {
            new Criminal("Потоцкий Роман Юрьевич", "Поляк", 168, 51, false),
            new Criminal("Иванов Иван Иванович", "Русский", 168, 51, true),
            new Criminal("Петров Петр Петрович", "Украинец", 170, 60, false),
            new Criminal("Дмитров Дмитрий Дмитриевич", "Украинец", 170, 60, false),
            new Criminal("Алексеев Алексей Алексеевич", "Украинец", 170, 60, true)
        };

            public void Work()
            {
                string userInput;
                bool isWork = true;

                Console.WriteLine("Добро пожаловать в детективное агенство!");
                while (isWork)
                {
                    Console.WriteLine("Введите команду:\n1 - Найти преступника в базе данных\n2 - Выйти из детективного агенства");
                    userInput = Console.ReadLine();

                    switch (userInput)
                    {
                        case "1":
                            FindCriminal();
                            break;
                        case "2":
                            isWork = false;
                            break;
                        default:
                            break;
                    }
                }

                Console.WriteLine("Вы вышли из детективного агенства");
            }

            private void FindCriminal()
            {
                int weight;
                int height;
                string nationality;

                Console.WriteLine("Введите данные о преступнике:");

                Console.WriteLine();
                Console.WriteLine("Рост");
                height = EnterNumber();

                Console.WriteLine();
                Console.WriteLine("Вес");
                weight = EnterNumber();

                Console.WriteLine();
                Console.WriteLine("Национальность");
                nationality = Console.ReadLine();

                Console.WriteLine();

                var filteredCriminals = from Criminal criminal in _criminals
                                        where criminal.Height == height && criminal.Weight == weight && criminal.Nationality == nationality && criminal.IsArrested == false
                                        select criminal;

                if (filteredCriminals.Count() == 0)
                {
                    Console.WriteLine("Таких преступников нет в базе данных");
                }
                else
                {
                    foreach (var criminal in filteredCriminals)
                    {
                        Console.WriteLine(criminal.Name);
                    }
                }
            }

            private int EnterNumber()
            {
                string number;
                int parsedNumber = 1;
                bool isParsed = false;

                while (isParsed == false)
                {
                    Console.WriteLine("Введите число");
                    number = Console.ReadLine();

                    if (int.TryParse(number, out parsedNumber) && parsedNumber > 0)
                    {
                        isParsed = true;
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели неправильно число!");
                    }
                }

                return parsedNumber;
            }
        }

        class Criminal
        {
            public string Name { get; private set; }
            public string Nationality { get; private set; }
            public int Height { get; private set; }
            public int Weight { get; private set; }
            public bool IsArrested { get; private set; }

            public Criminal(string name, string nationality, int height, int weight, bool isArrested)
            {
                Name = name;
                Nationality = nationality;
                Height = height;
                Weight = weight;
                IsArrested = isArrested;
            }
        }
    }
}
