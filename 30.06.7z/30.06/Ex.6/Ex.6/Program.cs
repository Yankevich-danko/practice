﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Ex._6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Archive archive = new Archive();
            archive.ShowNamesAndRanks();
        }
    }

    class Archive
    {
        private List<Soldier> _soldiers;

        public Archive()
        {
            _soldiers = new List<Soldier>();
            _soldiers.Add(new Soldier("Белов Марк Владиславович", "Рядовой", "Автомат", 10));
            _soldiers.Add(new Soldier("Кузнецов Кирилл Филиппович", "Рядовой", "Автомат", 11));
            _soldiers.Add(new Soldier("Медведев Артемий Петрович", "Сержант", "Гранатомёт", 12));
            _soldiers.Add(new Soldier("Логинов Елисей Григорьевич", "Сержант", "Пулемёт", 13));
            _soldiers.Add(new Soldier("Лапшин Андрей Георгиевич", "Старший сержант", "Пистолет", 22));
        }

        public void ShowNamesAndRanks()
        {
            var sortedSoldier = from Soldier soldier in _soldiers
                                select new
                                {
                                    name = soldier.Name,
                                    title = soldier.Title
                                };
            Console.WriteLine("Приложение - Отчет о вооружении.\nВ данной программе есть класс солдата.В нём есть поля: имя, вооружение, звание, срок службы(в месяцах).Написать запрос, " +
                "при помощи которого получить набор данных состоящий из имени и звания. Вывести все полученные данные в консоль. (Не менее 5 записей).");
            foreach (var soldier in sortedSoldier)
            {
                Console.WriteLine($"ФИО: {soldier.name}. Звание: {soldier.title}.");
            }
        }
    }

    class Soldier
    {
        private string _armament;
        private int _lifespan;

        public Soldier(string name, string title, string armament, int lifespan)
        {
            Name = name;
            Title = title;
            _armament = armament;
            _lifespan = lifespan;
        }

        public string Name { get; private set; }
        public string Title { get; private set; }
    }
}
