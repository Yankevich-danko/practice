﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Ex._5
{
    class Program
    {
        static void Main(string[] args)
        {
            List<PotMeat> potMeats = new List<PotMeat>()
            {
                new PotMeat("Тушенка русская", 1998, 15),
                new PotMeat("Тушенка французская", 1990, 25),
                new PotMeat("Тушенка химическая", 1999, 20),
                new PotMeat("Тушенка вареная", 2015, 3),
                new PotMeat("Тушенка свинная", 2019, 3),
                new PotMeat("Тушенка багамская", 2019, 5),
            };
          

            int currentYear = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
            IEnumerable<PotMeat> resultDelayPotMeat = potMeats.Where(pm => pm.DateProduction + pm.YearsOfValidity < currentYear);

            Console.WriteLine("Просрочка:");
            foreach (PotMeat potMeat in resultDelayPotMeat)
            {
                Console.WriteLine(potMeat.Name + " - " + potMeat.DateProduction + " - " + potMeat.YearsOfValidity + " - последний срок годности: " + (potMeat.DateProduction + potMeat.YearsOfValidity));
            }
        }
    }

    class PotMeat
    {
        public string Name { get; private set; }
        public int DateProduction { get; private set; }
        public int YearsOfValidity { get; private set; }

        public PotMeat(string name, int dateProduction, int yearsOfValidity)
        {
            Name = name;
            DateProduction = dateProduction;
            YearsOfValidity = yearsOfValidity;
        }
    }
}