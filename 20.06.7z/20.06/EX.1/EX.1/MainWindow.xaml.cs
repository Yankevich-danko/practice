﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EX._1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
         void Payment(int platej)
        {
            int credit = Convert.ToInt32(summ2.Text);
            int sum = credit - platej;
            if (sum <= 0)
            {
               summ2.Text = 0 + "";
                MessageBox.Show("Долг отсутствует. Переплата: " + (platej - credit));
            }
            else
                summ2.Text = sum + "";

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int paument = Convert.ToInt32(summ.Text);
            Payment(paument);
        }
    }
}
