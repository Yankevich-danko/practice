﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ex._3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        double Ostk(double a, double b)
        {
           
            return (a % b);
        }

        double Step(double a, double b)
        {
            
            return Math.Pow(a, b);
        }

        string Conc(string a, string b)
        {
            return a + b;
        }

        double Div(double a, double b)
        {
            return (a / b);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string a = tb1.Text;
            string b = tb2.Text;

            if(rb1.IsChecked == true)
                tb3.Text = Ostk(Convert.ToDouble(a), Convert.ToDouble(b)) + "";
            else if (rb2.IsChecked == true)
                tb3.Text = Step(Convert.ToDouble( a), Convert.ToDouble (b)) + "";
            else if (rb3.IsChecked == true)
                tb3.Text = Conc(a, b);
            else if (rb4.IsChecked == true)
                tb3.Text = Div(Convert.ToDouble(a), Convert.ToDouble(b)) + "";
            else
                MessageBox.Show("Выберите действие");
        }
    }
}
