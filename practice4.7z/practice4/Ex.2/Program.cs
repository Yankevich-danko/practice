﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;

namespace Ex._3
{
    static class MyFileClass
    {
        //Метод создания файла
        public static void CreateFile(string filePath)
        {
            var file = new FileStream(filePath, FileMode.Create);
            file.Close();
            Console.WriteLine("Пустой файл создан!");
        }

        //Метод записи в файл
        public static void WriteInFile(string filePath)
        {
            try
            {
                var file = new FileStream(filePath, FileMode.Open);
                //Создание потока для записи в файл одним из возможных способов
                var strWrite = new StreamWriter(file);
                Console.WriteLine("Введите строку текста в файл:");
                strWrite.WriteLine(Console.ReadLine());
                strWrite.Close();
                file.Close();
                Console.WriteLine("Файл сохранен!");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Файл удален или не был создан");
            }
        }

        //Метод чтения в файл
        public static void ReadFromFile(string filePath)
        {

            try
            {
                //Создание потока для чтения из файла одним из возможных способов
                var strRead = File.OpenText(filePath);
                Console.WriteLine("Текст в файле:");
                Console.WriteLine(strRead.ReadLine());
                strRead.Close();
                Console.WriteLine("Файл прочтён!");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Файл удален или не был создан");
            }
        }

        public static void Delete(string filePath)
        {
            File.Delete(filePath);
            Console.WriteLine("Файл Удален!");
        }
    }
        class Program
    {
        public static string ReadAllText(string filePath)
        {
            using (FileStream stream = File.OpenRead(filePath))
            {
                var encoding = new UTF8Encoding(true);
                var reader = new StreamReader(stream, encoding);
                return reader.ReadToEnd();
            }
        }
        static void Search(DirectoryInfo dr, Regex file)
        {
            FileInfo[] fi = dr.GetFiles();
            foreach (FileInfo info in fi)
            {
                if (file.IsMatch(info.Name))
                {
                    Console.WriteLine("{0,-20} | {1}", info.Directory.Name, info.Name);
                }
            }
            DirectoryInfo[] dirs = dr.GetDirectories();
            foreach (DirectoryInfo directoryInfo in dirs)
            {
                Search(directoryInfo, file);
            }
        }

       


        static void Main()
        {
            //Относительный путь к папке
            string path = @"C:/test/";

            //Открытие папки для наглядности
            Process.Start("explorer.exe", path);
            Console.WriteLine("Папка открыта для наглядности\nВедите имя нового файла:");

            //Ввод имени файла
            string fileName = Console.ReadLine();

            //Путь к файлу
            string filePath = path + @"\" + fileName;

            //Создание или открытие файла
            MyFileClass.CreateFile(filePath);

            //Создание или открытие файла
            MyFileClass.WriteInFile(filePath);
            Console.WriteLine("Для открытия нажмите любую кнопку...");
            Console.ReadKey();

            //Чтения из файла
            MyFileClass.ReadFromFile(filePath);

            Console.WriteLine("Вы хотите удалить директории? \n1 Да\n2 нет");

            int a = Convert.ToInt32(Console.ReadLine());

            if (a == 1)
            {
                Console.WriteLine("Для удаления нажмите любую кнопку...");
                Console.ReadKey();

                //Удаление файла
                MyFileClass.Delete(filePath);
            }
            else if (a == 2)
            {
                Console.WriteLine("Проверьте файл");
            }
            else
            {
                Console.WriteLine("Вы хотите удалить директории? \n1 Да\n2 нет");
            }
         
    
        }
    }
}
