﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ex._3_
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        string path;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StreamWriter sw = new StreamWriter(path);
                sw.WriteLine(tb1.Text);
                MessageBox.Show( "Файл сохранён");
                sw.Close();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            FileStream ofs = File.Open(path, FileMode.Open);
            FileStream cfs = File.Create(path + ".gz");
            GZipStream compressor = new GZipStream(cfs, CompressionMode.Compress);
            ofs.CopyTo(compressor);
            compressor.Close();
            ofs.Close();
            cfs.Close();
            MessageBox.Show("Файл успешно сжат");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                path = tb2.Text + ".txt";
                StreamReader sr = new StreamReader(path);
                tb1.Text = sr.ReadToEnd();
                sr.Close();
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
    }
}
