﻿using System;
using System.IO;

namespace Ex._1
{
    class Program
    {
        static void Main(string[] args)
        {

            for (int i = 0; i < 100; i++)
            {
                String dirPath = $@"C:/test/Folder_{i}";


                bool exist = Directory.Exists(dirPath);
                if (!exist)
                {
                    Console.WriteLine(dirPath + " does not exist.");
                    Console.WriteLine("Create directory: " + dirPath);


                    Directory.CreateDirectory(dirPath);
                }
            }

            Console.WriteLine("Директории успешно созданы");
            Console.WriteLine("Вы хотите удалить директории? \n1 Да\n2 нет");

            int a = Convert.ToInt32(Console.ReadLine());

            if (a == 1)
            {
                string dir = @"C:/test/";
                Directory.Delete(dir, true); 
                Directory.CreateDirectory(dir);
                Console.WriteLine("Успешно удалено");
            }
            else if (a == 2)
            {
                Console.WriteLine("Проверьте директории");
            }
            else
            {
                Console.WriteLine("Вы хотите удалить директории? \n1 Да\n2 нет");
            }
        }
    }
}
