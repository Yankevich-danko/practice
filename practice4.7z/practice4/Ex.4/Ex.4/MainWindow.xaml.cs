﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Wpf.Toolkit;

namespace Ex._4
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            string color;
            try
            {
                IsolatedStorageFileStream isolatedStorageFileStream = new IsolatedStorageFileStream("ColorLabel.cfg", FileMode.Open, FileAccess.Read, FileShare.Read);
                StreamReader reader = new StreamReader(isolatedStorageFileStream);
                color = reader.ReadLine();
                LC.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color));
                LC.Content = color;
                reader.Close();
            }
            catch (Exception )
            {
                LC.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00000000"));
                LC.Content = "#00000000";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.MessageBox.Show("Сохранено. Перезапустите приложение");
        }

        private void CP_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
        {
            IsolatedStorageFileStream isolatedStorageFileStream = new IsolatedStorageFileStream("ColorLabel.cfg", FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite);
            StreamWriter writer = new StreamWriter(isolatedStorageFileStream);
            LC.Content = ColorPicker.SelectedColor.Value;
            LC.Background = new SolidColorBrush(ColorPicker.SelectedColor.Value);
            writer.WriteLine(LC.Background.ToString());
            writer.Close();
        }

    }
}
